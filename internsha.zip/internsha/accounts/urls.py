from django.urls import path,include
from . import views
from django.contrib.auth import views as auth_views


urlpatterns = [
    path('',views.home,name="home"),
    path('login/',views.loginn,name="login"),
    path('accounts/login/',views.loginng,name="loginn"),
    path('signup/',views.signup,name="signup"),
    path('validate/',views.validate,name="validate"),
    path('validates/',views.validates,name="validates"),
    path('logout/',views.logout,name="logoutt"),
    path('locavo/',views.index,name= "index"),
    path('activate/<uidb64>/<token>/', views.activate, name='activate'),
    path('password_reset/', auth_views.PasswordResetView.as_view( template_name='password_reset_form.htm'), name='password_reset'),
    path('password_reset/done/', auth_views.PasswordResetDoneView.as_view(template_name='password_reset_done.htm'), name='password_reset_done'),
    path('password_reset/confirm/<uidb64>/<token>/', auth_views.PasswordResetConfirmView.as_view(template_name='password_reset_email.htm'), name='password_reset_confirm'),
    path('password_reset/complete/', auth_views.PasswordResetCompleteView.as_view(template_name='password_reset_complete.htm'), name='password_reset_complete'),
   
]
