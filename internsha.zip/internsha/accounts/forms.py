from django import forms
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.models import User



class UserSignUpForm(UserCreationForm):
    username = forms.CharField( max_length=30, required=True,widget=forms.TextInput(attrs={'placeholder': 'Username'}))
    first_name = forms.CharField(max_length=30, required=True,widget=forms.TextInput(attrs={'placeholder': 'First Name'}))
    last_name = forms.CharField(max_length=30, required=True,widget=forms.TextInput(attrs={'placeholder': 'Last Name'}))
    email = forms.EmailField(max_length=100,label = 'email',widget=forms.TextInput(attrs={'placeholder': 'Email'}))
    password1 = forms.CharField(label = 'password',widget=forms.PasswordInput(attrs={'placeholder': 'Password'}))
    #password2 = forms.CharField(label = 'password',widget=forms.PasswordInput(attrs={'placeholder': 'Confirm Password'}))
    class Meta:
        model = User
        fields = ('username','first_name', 'last_name', 'email', 'password1')

    def __init__(self, *args, **kwargs): 
        super(UserSignUpForm, self).__init__(*args, **kwargs) 
        # remove username
        self.fields.pop('password2')

    def clean_email(self):
        email = self.cleaned_data.get('email')
        username = self.cleaned_data.get('username')
        if email and User.objects.filter(email=email).exists():
            raise forms.ValidationError('Account already exist with this email')
        return email
        
    

