from django.http import HttpResponse
from django.shortcuts import render, redirect
from django.contrib.auth import  authenticate,login 
from .forms import UserSignUpForm
from django.contrib.sites.shortcuts import get_current_site
from django.utils.encoding import force_bytes, force_text
from django.utils.http import urlsafe_base64_encode, urlsafe_base64_decode
from django.template.loader import render_to_string
from .token_generator import account_activation_token
from django.contrib.auth.models import User ,auth
from django.core.mail import EmailMessage
from django.contrib.auth.models import User
from django.contrib.auth.decorators import login_required
from django.shortcuts import render, get_object_or_404


# Create your views here.
def home(request):
    return render(request,"home.htm")

def loginn(request):
    return render(request,"login.htm")

def loginng(request):
    return render(request,"login.htm")

def signup(request):
    
    form = UserSignUpForm()
    return render(request, 'signup.htm', {'form': form})

def validate(request):
    if request.method == 'POST':       
        form = UserSignUpForm(request.POST) 
        if form.is_valid():
            user = form.save(commit=False)
            user.is_active = False
            user.save()
            current_site = get_current_site(request)
            message = render_to_string('activate_account.htm', {
                'user':user, 
                'domain':current_site.domain,
                'uid': urlsafe_base64_encode(force_bytes(user.pk)),
                'token': account_activation_token.make_token(user),
            })
            mail_subject = 'Activate your blog account.'
            to_email = form.cleaned_data.get('email')
            email = EmailMessage(mail_subject, message, to=[to_email])
            email.send()
            return render(request,"signup.htm",{'msg':'Please confirm your email address to complete the registration','form':form})
    
    else:
        form = UserSignUpForm()
    
    return render(request, 'signup.htm', {'form': form})

def activate(request, uidb64, token):
    try:
        uid = force_bytes(urlsafe_base64_decode(uidb64))
        user = User.objects.get(pk=uid)
    except(TypeError, ValueError, OverflowError, User.DoesNotExist):
        user = None
    if user is not None and account_activation_token.check_token(user, token):
        user.is_active = True
        user.save()
        login(request,user)
        form = UserSignUpForm()
        return render(request,"signup.htm",{'msg':'Acoount is Succesfully registered. PLEASE LOGIN','form':form})
    else:
        return HttpResponse('Activation link is invalid!')
        
     
def validates(request):
    if request.method == 'POST':
        if not request.POST.get('remember', None):
            request.session.set_expiry(0)
        email = request.POST['email']
        try:
            user = User.objects.get(email=email)
        except:
            return render(request, 'login.htm',{'msg':'Not Valid Email. Please Signup'})
        username = User.objects.get(email=request.POST['email']).username
        user = authenticate(username= username,password=request.POST['password'])
        if user is not None:
            login(request,user)
            return redirect('home')
        else:
            return render(request, 'login.htm',{'msg':'Password is incorrect.'})
    else:
        return render(request, 'login.htm')


def logout(request):
    if request.method == 'POST':
        auth.logout(request)
        return redirect('home')

def PasswordResetView(request):
    return render(request,"password_reset_form.htm")



@login_required
def index(request):
    return render(request, 'home.htm')



